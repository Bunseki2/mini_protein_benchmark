# Script to compute structural and sequence metrics
